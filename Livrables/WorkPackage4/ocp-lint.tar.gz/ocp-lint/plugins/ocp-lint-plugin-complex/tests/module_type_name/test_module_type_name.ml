module type CORRECT = sig
  val value : string
end

module type NotCorrect = sig
  val value : string
end
