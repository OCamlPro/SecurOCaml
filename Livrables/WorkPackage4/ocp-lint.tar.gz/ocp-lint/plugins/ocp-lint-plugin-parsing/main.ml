
let () = Lint.main ()
