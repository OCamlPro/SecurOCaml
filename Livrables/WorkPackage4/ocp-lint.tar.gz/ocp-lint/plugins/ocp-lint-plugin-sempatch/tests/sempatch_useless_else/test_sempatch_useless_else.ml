
let my_fun cond expr =
  if cond then expr else ()
