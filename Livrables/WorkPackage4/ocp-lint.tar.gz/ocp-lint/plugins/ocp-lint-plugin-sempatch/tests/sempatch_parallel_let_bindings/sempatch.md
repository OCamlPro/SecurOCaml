@Multiple_parallel_let
```
let _x = 1 and _y = 2 and _z = 3 in ()
```
