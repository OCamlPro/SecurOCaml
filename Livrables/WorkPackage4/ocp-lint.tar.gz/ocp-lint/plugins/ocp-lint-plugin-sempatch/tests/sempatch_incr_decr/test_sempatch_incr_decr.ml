
let test_incr () =
  let cpt = ref 0 in
  cpt := !cpt + 1

let test_descr () =
  let cpt = ref 0 in
  cpt := !cpt - 1
