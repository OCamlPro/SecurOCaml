
let () =
  let var = 1 + 1 in
  var

let () =
  let rec rec_var = 1 ::rec_var in
  rec_var

let () =
  let vary = 4 in
  let varx = 1 + 2 in
  vary
