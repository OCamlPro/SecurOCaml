
let test_empty_list_cmp cond =
  if cond then true else false
