
let my_fun cond expr =
  if cond then () else expr
