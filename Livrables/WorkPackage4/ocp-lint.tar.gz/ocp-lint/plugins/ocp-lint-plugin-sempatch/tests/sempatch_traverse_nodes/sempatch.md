@FindAllFoos
message : found
```
foo
```
