
let test_empty_list_cmp cond expr =
  if cond then expr else expr
