# Ocp-lint-doc: Web page generator

This tool will generate a web page listing the plugings with their linters
and warnings.

## Dependencies

Omd, tyxml

## Build Instructions

    $ make

## Running

Use `_obuild/ocp-lint-doc/ocp-lint-doc.{asm,byte}`

This will generate a index.html in tools/ocp-lint-doc