let _ =
  if some_bool then
    1
  else
    (Printf.printf "...";
     2)
