List.map (fun a -> a + 1) []
