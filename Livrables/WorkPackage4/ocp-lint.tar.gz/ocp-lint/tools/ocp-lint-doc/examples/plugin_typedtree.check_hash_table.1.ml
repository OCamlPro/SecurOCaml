Hashtbl.create 10
