module Location = struct end
