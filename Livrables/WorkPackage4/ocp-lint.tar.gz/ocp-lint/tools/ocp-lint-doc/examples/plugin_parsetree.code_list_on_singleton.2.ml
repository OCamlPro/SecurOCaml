List.iter print_endline [ "singleton" ]
