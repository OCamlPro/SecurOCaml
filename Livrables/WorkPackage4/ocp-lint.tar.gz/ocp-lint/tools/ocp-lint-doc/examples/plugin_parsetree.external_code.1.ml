external add : int -> int =
  "add"
