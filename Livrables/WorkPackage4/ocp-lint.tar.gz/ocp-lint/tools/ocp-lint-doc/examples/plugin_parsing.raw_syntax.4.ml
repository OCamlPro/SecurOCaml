type a = A of (int)
