Dynlink.loadfile "f.ml"
