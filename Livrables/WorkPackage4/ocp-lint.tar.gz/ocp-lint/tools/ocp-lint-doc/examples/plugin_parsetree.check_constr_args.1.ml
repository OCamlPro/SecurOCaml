type t = A of (int * int) | B of int
