open String
