let p = (0, 0)
