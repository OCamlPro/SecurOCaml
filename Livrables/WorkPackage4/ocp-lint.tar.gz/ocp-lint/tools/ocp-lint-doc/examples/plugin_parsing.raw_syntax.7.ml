let _ =
  if some_bool then
    (Printf.printf "...";
     1)
  else
    2
