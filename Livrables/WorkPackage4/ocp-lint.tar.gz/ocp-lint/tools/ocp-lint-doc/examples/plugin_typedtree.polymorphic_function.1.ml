type t = A of int

let _ =
  (A 3) = (A 4)
