match foo with
| None -> -1
| Some i ->
  match i with
  | xxx -> 2
  | _ -> 3
