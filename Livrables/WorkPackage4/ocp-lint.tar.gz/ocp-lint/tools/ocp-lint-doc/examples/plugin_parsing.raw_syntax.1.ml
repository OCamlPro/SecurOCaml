if (some_boolean) then
  expr
else
  expr
