"String1" == "String2"
