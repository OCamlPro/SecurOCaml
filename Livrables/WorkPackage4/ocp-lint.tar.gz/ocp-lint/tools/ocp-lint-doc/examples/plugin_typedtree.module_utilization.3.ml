Random.init 0
