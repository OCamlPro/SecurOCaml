let f = function
  | x when x > 10 -> 2
  | _ -> 1
