//Provides: re_search_forward
function re_search_forward () { return 1; }
