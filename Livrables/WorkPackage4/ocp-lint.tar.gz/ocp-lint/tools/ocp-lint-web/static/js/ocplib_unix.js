//Provides: minUnix_cleanup
function minUnix_cleanup () { return 1; }

//Provides: minUnix_filedescr_of_fd
function minUnix_filedescr_of_fd  () { return 1; }

//Provides: minUnix_startup
function minUnix_startup () { return 1; } // Bad_term
