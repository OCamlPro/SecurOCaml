open Pervasives

let x = 1

let () = print_endline "This file only exists for testing purpose"

let y = x + 2

let z = y * y

let () = print_endline "Please make sure that it won't throw any exception when you edit it"

let () = print_endline "Please also make sure that the analysis won't see any cranky exception"

