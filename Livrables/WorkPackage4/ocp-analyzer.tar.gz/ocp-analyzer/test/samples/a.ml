open Pervasives

let x = 4

let y = min 3 5

let z = x + y

let a = if z = 7 then () else assert false
