let f ?(a = 0) ?(b = 0) x = a + b + x
let g ?(a = 0) ?(b = 0) x = a + b + x
