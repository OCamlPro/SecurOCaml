let f x = 12
let g x = 0
